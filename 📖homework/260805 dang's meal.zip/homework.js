const MENU_KEY = "mealExample";
const menu = ["한식", "양식", "면류", "간식"];

const initialDiaries = [
      {
        id: 1,
        menu: "한식",
        title: "불고기",
        content: "짜다 짜..\n야채가 하나도 없어서 아쉽..",
        createdAt: "2026. 08. 01"
      },
      {
        id: 2,
        menu: "한식",
        title: "김치찌개",
        content: "너무 많이 끓여서 내일도 먹어야겠군",
        createdAt: "2026. 08. 02"
      },
      {
        id: 3,
        menu: "면류",
        title: "비빔소면",
        content: "여름엔 소면이지!",
        createdAt: "2026. 08. 03"
      },
      {
        id: 4,
        menu: "간식",
        title: "핫도그",
        content: "존마탱구리, JMTGR 이라고 하죠?",
        createdAt: "2026. 08. 04"
      }
    ];

let menulistData = [];
let currentFilter = "전체";
let currentSearch = "";
let selectedDiaryId = null;
let editingDiaryId = null;

const menulist = document.getElementById("menulistData");
const filterButtons = document.getElementById("filterButtons");
const diaryForm = document.getElementById("diaryForm");
const titleInput = document.getElementById("titleInput");
const contentInput = document.getElementById("contentInput");
const submitButton = document.getElementById("submitButton");
const detailBox = document.getElementById("detailBox");
const editButton = document.getElementById("editButton");
const clearButton = document.getElementById("clearButton");
const searchInput = document.getElementById("searchInput");

// 로컬스토리지에서 배열을 꺼내는 함수예요.
const loadmenulist = () => {
    const saved = localStorage.getItem(MENU_KEY);
    if (saved === null) {
    return initialDiaries;
    }

    try {
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : initialDiaries;
    } catch {
    return initialDiaries;
    }
};

// 배열을 다시 저장하는 함수예요.
const saveDiaryList = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(diaryListData));
};

const getmenuEmoji = (menu) => {
    if (menu === "한식") return "🍚";
    if (menu === "양식") return "🥩";
    if (menu === "면류") return "🍜";
    return "🥨";
};

const getmenuClass = (menu) => {
    if (menu === "한식") return "thumb-happy";
    if (menu === "양식") return "thumb-sad";
    if (menu === "면류") return "thumb-gray";
    return "thumb-pink";
};

const getmenuLabel = (menu) => {
    if (menu === "한식") return "한식🍚";
    if (menu === "양식") return "양식🥩";
    if (menu === "면류") return "면류🍜";
    return "간식🥨";
};

const getTodayText = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}. ${month}. ${day}`;
};

// 라디오 버튼에서 체크된 값을 forEach로 찾아요.
const getSelectedmenu = () => {
    const menuInputs = document.querySelectorAll('input[name="menu"]');
    let selectedmenu = "기타";

    menuInputs.forEach((input) => {
    if (input.checked) {
        selectedmenu = input.value;
    }
    });

    return selectedmenu;
};

// 필터 버튼을 만들어줘요.
const renderFilterButtons = () => {
    filterButtons.innerHTML = menus.map((menu) => {
    const isActive = menu === currentFilter ? "active" : "";
    return `<button type="button" class="filter-btn ${isActive}" data-filter="${menu}">${menu}</button>`;
    }).join("");
};

// 목록은 map으로 만들고, filter로 골라서 보여줘요.
const renderDiaryList = () => {
    const visibleList = diaryListData.filter((diary) => {
        const matchFilter = currentFilter === "전체" || diary.menu === currentFilter;
        const searchText = `${diary.title} ${diary.content}`.toLowerCase();
        const matchSearch = searchText.includes(currentSearch.toLowerCase());
        return matchFilter && matchSearch;
    });

    if (visibleList.length === 0) {
        diaryList.innerHTML = `
            <div class="empty-state">
            조건에 맞는 일기가 없어요. 필터를 바꾸거나 새로운 일기를 등록해보세요.
            </div>
        `;
        return;
    }

    diaryList.innerHTML = visibleList.map((diary) => {
        return `
          <article class="diary-card" onclick="showDiaryDetail(${diary.id})">
            <div class="diary-card-top">
              <div class="diary-menu">${getmenuLabel(diary.menu)}</div>
              <div class="diary-date">${diary.createdAt}</div>
            </div>

            <div class="diary-thumb ${getmenuClass(diary.menu)}">${getmenuEmoji(diary.menu)}</div>

            <h3>${diary.title}</h3>
            <p>${diary.content.slice(0, 70)}${diary.content.length > 70 ? "..." : ""}</p>

            <div class="diary-card-footer">
              <span class="diary-link" onclick="event.stopPropagation()">
                <a href="#detail-area">상세 보기</a>
              </span>
              <span class="diary-date">#${diary.menu}</span>
            </div>
          </article>
        `;
    }).join("");
};

const setDetailBox = (diary) => {
      if (diary === undefined) {
        detailBox.innerHTML = `
          <h3>아직 선택한 일기가 없어요.</h3>
          <p class="detail-content">왼쪽 목록에서 카드 하나를 눌러보세요. 상세 내용이 여기에 보여요.</p>
        `;
        editButton.disabled = true;
        selectedDiaryId = null;
        return;
      }

      detailBox.innerHTML = `
        <h3>${diary.title}</h3>
        <div class="detail-meta">
          <span>${getmenuLabel(diary.menu)} ${getmenuEmoji(diary.menu)}</span>
          <span>${diary.createdAt}</span>
        </div>
        <div class="detail-content">${diary.content}</div>
      `;
      editButton.disabled = false;
      selectedDiaryId = diary.id;
    };

    